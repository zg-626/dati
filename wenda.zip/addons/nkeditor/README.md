# NKeditor
NKedtior是基于 kindeditor 进行二次开发的项目
kindeditor 是一款优秀的开源在线编辑器。轻量级且功能强大，代码量却不到百度的ueditor编辑器的一半。可惜已经4年没有更新了，由于业务的需求我们在kindeditor的基础上开发了 NKeditor, 主要做了一下工作：
1. 调整编辑器和弹出 dialog 的样式，美化了UI
2. 重写图片上传和批量图片上传插件，使用 html5 上传代替了 flash,实现了待上传图片预览，优化用户体验
3. 修复一些已知的bug，如 ajax 提交无法获取内容等
4. 新增涂鸦等功能

再次感谢 kindeditor 的开发者，为我们提供了如此优秀的在线编辑器，让我们能在前人的基础上继续贡献自己的微薄之力。

# 开源说明
本插件基于Nkeditor进行二次开发，修改的核心文件已开源于 https://gitee.com/karson/kindeditor 

# 特别感谢
[Kindeditor](https://gitee.com/luolonghao/kindeditor)
[Nkeditor](https://gitee.com/blackfox/kindeditor)

