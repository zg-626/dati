<?php return array (
  'language' => 'zh_CN',
  'plugins' => 'autolink,autosave,print,preview,spellchecker,fullscreen,media,emoticons,template,paste,textcolor',
  'toolbar' => '1',
  'content_style' => '',
  'image_default_size' => '{width:\'100%\',height:\'\'}',
  'up_video' => '0',
  'media_default_size' => '{width:\'100%\',height:\'\'}',
  'subDom' => ':button[type=submit],input[type=submit]',
);