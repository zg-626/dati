<?php

return [
    'Type'       => '类型',
    'Image'      => '图片',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Weigh'      => '权重',
    'Status'     => '状态',
    'Deletetime' => '删除时间'
];
