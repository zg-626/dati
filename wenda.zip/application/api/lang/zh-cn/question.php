<?php

return [
    'User_id'       => '用户',
    'Cid'           => '科目',
    'Image'         => '图片',
    'Content'         => '问题',
    'Reply'         => '回答',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间',
    'Status'        => '状态',
    'Normal'                                                => '已回答',
    'Hidden'                                                => '未回答',
    'User.username' => '用户名',
    'Category.name'      => '科目',
];
